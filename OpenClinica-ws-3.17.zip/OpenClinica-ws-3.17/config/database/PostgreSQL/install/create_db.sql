-- OpenClinica database creation script 
-- If the database already exists you will get : ERROR: database "openclinica" already exists SQL state: 42P04
-- 
CREATE DATABASE  openclinica
  WITH ENCODING='UTF8'
       OWNER=clinica;